
// import { createContext, useState } from "react"


// export const Level_Context = createContext({
//     Levels:{},
// })

// export const LevelContextProvider =({children})=>{
//     const [Levels,SetLevels] = useState([])

//     const  value ={Levels,SetLevels}
//     return (<Level_Context.Provider value={value}>{children}</Level_Context.Provider>)
// }

