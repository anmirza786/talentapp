export const REQUEST_URL = `https://talentmang.herokuapp.com/api/`;
