
// import { createContext, useState } from "react"


// export const Filters_Context = createContext({
//     FilterTitle:{},
// })

// export const FiltersContextProvider =({children})=>{
//     const [FilterTitle,SetFilterTitle] = useState([])

//     const  value ={FilterTitle,SetFilterTitle}
//     return (<Filters_Context.Provider value={value}>{children}</Filters_Context.Provider>)
// }

